'''
Based on the paper 'Hyperband: A Novel Bandit-Based Approach to Hyperparameter Optimization' by
 Li L., Jamieson K., DeSalvo G., Rostamizadeh A. and Talwalkar A.
'''

class Hyperband(object):
    def __init__(self):
        raise NotImplementedError
